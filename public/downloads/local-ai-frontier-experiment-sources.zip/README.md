# Local AI vs Frontier AI — Original experiment sources

This bundle contains the user-provided prompt and the **captured code** from the TypeScript `TaskScheduler` comparison. It is intended for the experiment article on paulkerr.com.au.

## Files

- `original-prompt.md`: original challenge specification, as shared in the conversation.
- `implementations/qwen3.6-35b-a3b-mtp.ts`: Qwen's **second, complete attempt** pasted in chat after its first response was cut off by context length. This implementation contains known defects; keep it unchanged for transparency.
- `implementations/codex-sol-6.1.ts`: Codex Sol 6.1 Light implementation pasted in chat.
- `implementations/claude-opus-5.5.ts`: Claude Opus 5.5 Medium implementation, copied from the uploaded plain-text code artifact (includes its `ScheduledTask` type alias).
- `CODEX-WEBSITE-BRIEF.md`: requested UI instructions for model tabs and expandable source code.

## Experiment notes

- Qwen: local RTX 5090, LM Studio 0.4.28, Unsloth Qwen3.6 35B-A3B MTP GGUF Q4; native MTP enabled. 265.98–270.17 tok/s across screenshots; 0.42–0.59 s time-to-first-token; roughly 64–67% accepted draft tokens. Its complete 12,169-token run implies ~45 seconds of **decoding only**, not an independently measured total response time. A later run produced 13,042 tokens at 265.98 tok/s (~49 seconds decoding).
- Codex: Sol 6.1 Light, recorded response time 54.6 seconds.
- Claude: Opus 5.5 Medium, reported response time 98 seconds, including reported compilation and 13 tests.
- Informal static-review scores discussed: Qwen 3/10, Codex 9/10, Claude 9/10. Not independently validated benchmark scores.

### Fairness and limitations

This was an informal single-task experiment, not a controlled benchmark. Qwen decoding-only time is not directly comparable to recorded end-to-end durations for the other two. Claude's compilation/test pass is self-reported. The code files are preserved as given, not corrected or independently test-verified in this bundle.

The user also supplied an earlier Qwen response that reached the context limit. Its full final code was not completed, so it is **not** included as a fourth code example.

## Publishing guidance

Present as original captured source, not as production-ready code. Expose the original prompt and the three code snippets using a compact, collapsible interface. Keep the experiment limitations visible.
