# Codex brief — source-code viewer for Local AI vs Frontier AI article

Existing personal website: paulkerr.com.au
Target article (if implemented): /learning/local-ai-vs-frontier

## Goal

Add an accessible, mobile-friendly, compact source section to the existing experiment article. It must present the *original task prompt* and source code from Qwen, Codex, and Claude. It must not dominate the page.

## Interaction

- Heading: "Read the original prompt and generated code"
- Display the original prompt in a collapsed "View challenge prompt" panel, expanded on user action.
- Add model-switcher tabs or segmented control: **Qwen local**, **Codex**, **Claude**. Default to Codex or Qwen, whichever best fits the article's story. Tabs must switch code without page navigation.
- Show just a ~12–20-line-high code preview by default. A clear "Read full code" / "Collapse code" control toggles the remaining source. Keep scrolling inside the code viewer if useful rather than creating an enormous page.
- Preserve indentation, syntax-highlight TypeScript, add line numbers if consistent with the site, provide a **Copy code** control.
- Keyboard/tab accessibility, mobile responsiveness, reduced-motion support, sensible line-wrap or horizontal scrolling.
- Add small context metadata per model, drawn from the README: model version, reported timing, and note on review status. Clearly label Qwen speed as estimated decoding-only, not wall time.
- Provide a **Download experiment sources (.zip)** link if this ZIP is placed in the site's public assets. Link the exact published asset, not a fabricated URL.
- Prefer native HTML details/summary or existing site components over new heavy dependencies. No giant animations in the source area.
- Do not silently edit or 'fix' any of the code. These are captured outputs. Preserve defects as evidence. If TypeScript isn't compilable as captured, note that rather than rewriting.

## Supplied files

- original-prompt.md — initial code challenge shared with models
- implementations/qwen3.6-35b-a3b-mtp.ts — Qwen second complete attempt (not its initial draft)
- implementations/codex-sol-6.1.ts — Codex implementation pasted in conversation
- implementations/claude-opus-5.5.ts — Claude implementation from uploaded source file
- README.md — provenance, timing caveats, methodology

## Acceptance

- Working tabs and expand/collapse, usable on iPhone and desktop
- Good code readability, no unnecessary page length, clear provenance and disclaimers
- Existing site build passes and source content is unchanged
- Don't deploy to production without user approval
